﻿using Microsoft.AspNetCore.Mvc;
using RegisterAndLoginApp.Filters;
using RegisterAndLoginApp.Models;
using System.Text.Json;

namespace RegisterAndLoginApp.Controllers
{
    public class GameController : Controller
    {
        private const string SessionKeyBoard = "_MinesweeperBoard";

        // Property to get/set the board from session
        private List<CellModel> Board
        {
            get
            {
                var boardJson = HttpContext.Session.GetString(SessionKeyBoard);
                return string.IsNullOrEmpty(boardJson) ? null : JsonSerializer.Deserialize<List<CellModel>>(boardJson);
            }
            set
            {
                var boardJson = JsonSerializer.Serialize(value);
                HttpContext.Session.SetString(SessionKeyBoard, boardJson);
            }
        }

        public IActionResult Index() => View();

        [HttpGet]
        public IActionResult Setup() => View(new MinesweeperModel());

        [HttpPost]
        public IActionResult Setup(MinesweeperModel model)
        {
            if (!ModelState.IsValid) return View(model);

            TempData["DifficultyLevel"] = model.DifficultyLevel.ToString();

            // Save rows and columns in session for persistent use across requests
            HttpContext.Session.SetInt32("Rows", model.Rows);
            HttpContext.Session.SetInt32("Columns", model.Columns);

            int bombs = GetBombCountByDifficulty(model.DifficultyLevel);
            Board = InitializeBoard(model.Rows, model.Columns, bombs);

            return RedirectToAction("Play");
        }

        [SessionCheckFilter]
        [HttpGet]
        public IActionResult Play()
        {
            if (Board == null) return RedirectToAction("Setup");

            ViewBag.DifficultyLevel = TempData["DifficultyLevel"]?.ToString() ?? "Easy";

            // Read rows and columns from session here
            ViewBag.Rows = HttpContext.Session.GetInt32("Rows") ?? 5;
            ViewBag.Columns = HttpContext.Session.GetInt32("Columns") ?? 5;

            return View(Board);
        }

        [HttpPost]
        public IActionResult CellClick(int id)
        {
            var board = Board;
            if (board == null) return RedirectToAction("Setup");

            var cell = board.FirstOrDefault(c => c.Id == id);
            if (cell != null && !cell.IsRevealed)
            {
                bool bombHit = RevealCell(board, cell);
                Board = board;  // Save updated board in session

                if (bombHit)
                {
                    return RedirectToAction("Loss");
                }

                if (AllSafeCellsRevealed(board))
                {
                    int score = CalculateScore(board);
                    return RedirectToAction("Win", new { score });
                }
            }

            return RedirectToAction("Play");
        }


        public IActionResult Loss()
        {
            // Clear the board/session so game ends
            HttpContext.Session.Remove(SessionKeyBoard);
            return View();
        }

        public IActionResult Win(int score)
        {
            // Clear the board/session as game ends
            HttpContext.Session.Remove(SessionKeyBoard);

            ViewBag.Score = score;
            return View();
        }

        private List<CellModel> InitializeBoard(int rows, int cols, int bombCount)
        {
            var cells = new List<CellModel>();
            int id = 0;

            // Create all cells
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    cells.Add(new CellModel(id++, r, c));

            // Place bombs randomly
            var rng = new Random();
            int bombsPlaced = 0;
            while (bombsPlaced < bombCount)
            {
                int index = rng.Next(cells.Count);
                if (!cells[index].IsBomb)
                {
                    cells[index].IsBomb = true;
                    bombsPlaced++;
                }
            }

            // Calculate adjacent bombs for each cell
            foreach (var cell in cells)
            {
                if (cell.IsBomb) continue;

                cell.AdjacentBombs = GetNeighbors(cells, cell, rows, cols).Count(n => n.IsBomb);
            }

            return cells;
        }

        private IEnumerable<CellModel> GetNeighbors(List<CellModel> cells, CellModel cell, int rows, int cols)
        {
            for (int dr = -1; dr <= 1; dr++)
            {
                for (int dc = -1; dc <= 1; dc++)
                {
                    if (dr == 0 && dc == 0) continue; // skip the cell itself

                    int nr = cell.Row + dr;
                    int nc = cell.Col + dc;

                    if (nr >= 0 && nr < rows && nc >= 0 && nc < cols)
                    {
                        yield return cells.First(x => x.Row == nr && x.Col == nc);
                    }
                }
            }
        }

        private bool RevealCell(List<CellModel> board, CellModel cell)
        {
            if (cell.IsRevealed) return false;

            cell.IsRevealed = true;

            if (cell.IsBomb)
            {
                cell.DisplayImage = "mine_hit.png"; // show mine hit image
                return true; // bomb hit
            }
            else
            {
                cell.DisplayImage = $"{cell.AdjacentBombs}.png";

                if (cell.AdjacentBombs == 0)
                {
                    int rows = HttpContext.Session.GetInt32("Rows") ?? 5;
                    int cols = HttpContext.Session.GetInt32("Columns") ?? 5;


                    foreach (var neighbor in GetNeighbors(board, cell, rows, cols))
                    {
                        if (!neighbor.IsRevealed)
                            RevealCell(board, neighbor);
                    }
                }

                return false; // no bomb hit
            }
        }
        private bool AllSafeCellsRevealed(List<CellModel> board)
        {
            // True if all cells that are NOT bombs are revealed
            return board.Where(c => !c.IsBomb).All(c => c.IsRevealed);
        }

        private int CalculateScore(List<CellModel> board)
        {
            // Example simple scoring: number of safe cells * difficulty multiplier
            int safeCells = board.Count(c => !c.IsBomb);
            int difficultyMultiplier = 1; // default easy

            if (TempData["DifficultyLevel"] != null)
            {
                var level = TempData["DifficultyLevel"].ToString();
                difficultyMultiplier = level switch
                {
                    "Easy" => 1,
                    "Medium" => 2,
                    "Hard" => 3,
                    _ => 1,
                };
            }

            // You can also incorporate elapsed time or board size here if you track that

            return safeCells * difficultyMultiplier;
        }


        private int GetBombCountByDifficulty(DifficultyLevel level) => level switch
        {
            DifficultyLevel.Easy => 5,
            DifficultyLevel.Medium => 10,
            DifficultyLevel.Hard => 15,
            _ => 5
        };
    }
}
