﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace RegisterAndLoginApp.Models
{
    public enum DifficultyLevel
    {
        Easy,
        Medium,
        Hard
    }
    public class MinesweeperModel
    {

        [Required]
        [DisplayName("Difficulty")]
        public DifficultyLevel DifficultyLevel { get; set; }

        [Required]
        [DisplayName("Board Size Rows")]
        [Range(5, 50)]
        public int Rows { get; set; } = 10;

        [Required]
        [DisplayName("Board Size Columns")]
        [Range(5, 50)]
        public int Columns { get; set; } = 10;



    }
}
