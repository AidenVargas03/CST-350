﻿namespace RegisterAndLoginApp.Models
{
    public class CellModel
    {
        // Unique cell ID (used for identifying the cell in UI and controller)
        public int Id { get; set; }

        // Position in grid
        public int Row { get; set; }
        public int Col { get; set; }

        // True if this cell contains a bomb
        public bool IsBomb { get; set; } = false;

        // Number of bombs adjacent to this cell (0-8)
        public int AdjacentBombs { get; set; } = 0;

        // Whether the cell has been revealed/clicked
        public bool IsRevealed { get; set; } = false;

        // Image filename to display for this cell (e.g., "0.png", "mine_hit.png")
        public string DisplayImage { get; set; } = "unexplored.png";

        // Optional: If you want to implement flags later
        public bool IsFlagged { get; set; } = false;

        // Parameterless constructor for model binding and serialization
        public CellModel() { }

        // Constructor with ID and grid coordinates
        public CellModel(int id, int row, int col)
        {
            Id = id;
            Row = row;
            Col = col;
            DisplayImage = "unexplored.png";
        }
    }
}
